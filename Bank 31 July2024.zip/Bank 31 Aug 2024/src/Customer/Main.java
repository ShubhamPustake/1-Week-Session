package Customer;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

      
        System.out.println("Enter customer name: ");
        String name = scanner.nextLine();
        System.out.println("Enter account number: ");
        String accountNumber = scanner.nextLine();

        
        Customer customer = new Customer(name, accountNumber);

       
        Account account = new Account(accountNumber, customer);

        System.out.println("Enter amount to deposit: ");
        double depositAmount = scanner.nextDouble();
        account.deposit(depositAmount);

       
        System.out.println("Enter amount to withdraw: ");
        double withdrawAmount = scanner.nextDouble();
        account.withdraw(withdrawAmount);

       
        System.out.println("Account balance:" + account.getBalance());

        System.out.println("Account holder: " + account.getCustomer().getname());

     
        scanner.close();
    }
}
