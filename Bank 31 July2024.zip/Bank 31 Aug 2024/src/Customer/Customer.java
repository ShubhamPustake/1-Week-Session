package Customer;

public class Customer {
 String  name;
 String accNumber;
  
 public Customer(String name, String accountNumber) {
     this.name = name;
     this.accNumber = accountNumber;
 }

 public String getAccountNumber() {
     return accNumber;
 }
 
 public String getname() {
	 return name;
 }
}
