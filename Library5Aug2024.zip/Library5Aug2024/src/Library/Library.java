package Library;
import java.util.Arrays;

public class Library {
    private String[] bookTitles;
    private int size;

    public Library(int capacity) {
        bookTitles = new String[capacity];
        size = 0;
    }

    public void addBookTitle(String title) {
        if (size == bookTitles.length) {
            bookTitles = Arrays.copyOf(bookTitles, size * 2);
        }
        bookTitles[size++] = title;
    }

    public void removeBookTitle(String title) {
        int index = searchBookTitle(title);
        if (index != -1) {
            for (int i = index; i < size - 1; i++) {
                bookTitles[i] = bookTitles[i + 1];
            }
            bookTitles[size - 1] = null;
            size--;
        }
    }

    public int searchBookTitle(String title) {
        for (int i = 0; i < size; i++) {
            if (bookTitles[i].equals(title)) {
                return i;
            }
        }
        return -1;
    }

    public void listAllBookTitles() {
        for (int i = 0; i < size; i++) {
            System.out.println(bookTitles[i]);
        }
    }

    public void sortBookTitles() {
      
        String[] subArray = Arrays.copyOf(bookTitles, size);
        Arrays.sort(subArray);
        System.arraycopy(subArray, 0, bookTitles, 0, size);
    }

    public static void main(String[] args) {
        Library library = new Library(5);
        library.addBookTitle("Java");
        library.addBookTitle("Python");
        library.addBookTitle("CPP");
        library.addBookTitle("R");

        System.out.println("All Book Titles:");
        library.listAllBookTitles();
        
        System.out.println("\nSorting Book Titles...");
        library.sortBookTitles();
        library.listAllBookTitles();
        
        System.out.println("\nSearching for 'CPP':");
        int index = library.searchBookTitle("CPP");
        System.out.println(index != -1 ? "Found at index: " + index : "Not found");
        
        System.out.println("\nRemoving 'R'...");
        library.removeBookTitle("R");
        library.listAllBookTitles();
    }
}
