package OneWeekSession;

public class NegativeDeposit extends RuntimeException{

	public NegativeDeposit(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}
	
	
}