package OneWeekSession;

public class InsufficientException extends RuntimeException{

	public InsufficientException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}
	

}
